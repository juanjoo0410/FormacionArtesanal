export interface Usuario {
    id: number,
    rol_id: number
}