export interface Estudiante {
    id?: number,
    cedula: string,
    nombres: string,
    apellidos: string,
    edad: number,
    direccion: string,
    email: string,
    telefono: string,
    contra: string,
    rol_id: number,
    nivel_educativo_id: number,
    medio_id: number
}