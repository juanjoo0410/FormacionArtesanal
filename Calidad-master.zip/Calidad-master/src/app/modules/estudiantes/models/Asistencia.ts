export interface Asistencia {
    id?: number,
    asistencia: number,
    dias_asistidos: number,
    dias_faltas: number
}