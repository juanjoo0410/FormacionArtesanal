export interface Horario {
    id?: number,
    curso_formado_id: number,
    materia: string,
    curso: string
}