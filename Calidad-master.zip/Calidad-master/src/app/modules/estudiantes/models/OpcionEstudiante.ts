export interface Opcion {
    class: string,
    nombre: string,
    metodo: string
}